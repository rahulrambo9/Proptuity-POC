package storage

import "log"

func InitDatabase() {
	log.Println("Initialize database connection here.")
}
